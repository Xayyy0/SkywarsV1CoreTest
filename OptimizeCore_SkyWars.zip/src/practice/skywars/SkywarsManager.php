<?php

declare(strict_types=1);

namespace practice\skywars;

use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use practice\Practice;

class SkywarsManager {

    /** @var SkywarsGame[] */
    private static array $games = [];

    public static function init(): void {
        // Sample default arena configuration
        // Spawns (Up to 12 player starts)
        $spawns = [
            "0:100:0", "15:100:15", "-15:100:15", "15:100:-15", "-15:100:-15",
            "30:100:0", "-30:100:0", "0:100:30", "0:100:-30",
            "20:100:20", "-20:100:20", "20:100:-20"
        ];

        // Chests (Where chests are located on the template map)
        $chests = [
            "2:101:2", "-2:101:2", "2:101:-2", "-2:101:-2",
            "10:101:10", "-10:101:10", "10:101:-10", "-10:101:-10"
        ];

        // Create a default Solo Skywars Arena
        self::createGame(
            "Solo",
            "skywars_template", // Template folder name inside worlds/
            "lobby",            // Lobby world name
            new Vector3(0.5, 100, 0.5), // Lobby spawn position
            $spawns,
            $chests
        );

        // Register the Repeating Tick Task inside Practice Scheduler
        Practice::getInstance()->getScheduler()->scheduleRepeatingTask(
            new ClosureTask(function(): void {
                foreach (self::$games as $game) {
                    $game->tick();
                }
            }),
            20 // Runs every 1 second (20 ticks)
        );
    }

    public static function createGame(
        string $arenaName,
        string $worldTemplate,
        string $lobbyWorldName,
        Vector3 $lobbySpawnLocation,
        array $spawns,
        array $chests
    ): void {
        self::$games[strtolower($arenaName)] = new SkywarsGame(
            $arenaName,
            $worldTemplate,
            $lobbyWorldName,
            $lobbySpawnLocation,
            $spawns,
            $chests
        );
    }

    /**
     * @return SkywarsGame[]
     */
    public static function getGames(): array {
        return self::$games;
    }

    public static function getGame(string $name): ?SkywarsGame {
        return self::$games[strtolower($name)] ?? null;
    }

    public static function getPlayerGame(Player $player): ?SkywarsGame {
        $name = strtolower($player->getName());
        foreach (self::$games as $game) {
            if (isset($game->getPlayers()[$name])) {
                return $game;
            }
        }
        return null;
    }
}
