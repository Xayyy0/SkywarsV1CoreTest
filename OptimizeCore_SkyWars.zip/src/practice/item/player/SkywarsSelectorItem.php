<?php

declare(strict_types=1);

namespace practice\item\player;

use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemUseResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use practice\item\PracticeItem;
use practice\session\SessionFactory;
use practice\form\duel\SkywarsSelectorForm;

class SkywarsSelectorItem extends PracticeItem{

	public function __construct(){
		parent::__construct('&eSkyWars', ItemTypeIds::ENDER_EYE);
	}

	public function onClickAir(Player $player, Vector3 $directionVector, array &$returnedItems) : ItemUseResult{
		$session = SessionFactory::get($player);

		if($session === null || !$session->inLobby()){
			return ItemUseResult::FAIL();
		}
		$form = new SkywarsSelectorForm();
		$player->sendForm($form);
		return ItemUseResult::SUCCESS();
	}
}
