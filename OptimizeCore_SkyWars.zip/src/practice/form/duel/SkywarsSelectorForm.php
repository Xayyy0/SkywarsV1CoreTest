<?php

declare(strict_types=1);

namespace practice\form\duel;

use cosmicpe\form\entries\simple\Button;
use cosmicpe\form\SimpleForm;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use practice\skywars\SkywarsManager;

final class SkywarsSelectorForm extends SimpleForm {

    public function __construct() {
        parent::__construct(TextFormat::colorize('&eSkyWars Arenas'));

        $games = SkywarsManager::getGames();

        if (empty($games)) {
            $this->addButton(new Button(TextFormat::colorize('&cNo arenas available')), function(Player $player, int $index): void {});
            return;
        }

        foreach ($games as $game) {
            $playersCount = count($game->getPlayers());
            $arenaName = $game->getArenaName();
            
            $buttonText = TextFormat::colorize(
                "&l&a" . $arenaName . "\n" .
                "&r&7Players: &f" . $playersCount . "/12"
            );

            $this->addButton(new Button($buttonText), function(Player $player, int $index) use ($game): void {
                $game->join($player);
            });
        }
    }
}
