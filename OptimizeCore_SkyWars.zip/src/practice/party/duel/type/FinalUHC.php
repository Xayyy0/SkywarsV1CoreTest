<?php

declare(strict_types=1);

namespace practice\party\duel\type;

use practice\party\duel\Duel;

final class FinalUHC extends Duel{
}